package com.example.mybrowserlt;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import androidx.recyclerview.widget.RecyclerView;

import org.litepal.crud.DataSupport;

import java.util.List;

public class ListAdapterLt extends ArrayAdapter<FavouritesLt> {
    private int resourceId;
    private Context mcontext;

    private List<FavouritesLt> favourites;
    public ListAdapterLt(Context context,  int textViewResourceId, List<FavouritesLt> objects) {
        super(context, textViewResourceId, objects);
        resourceId=textViewResourceId;
        mcontext=context;
        favourites = objects;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        FavouritesLt favouritesLt=getItem(position);
        View view;
        ViewHolder viewHolder;
        if (convertView==null){

            // 避免ListView每次滚动时都要重新加载布局，以提高运行效率
            view= LayoutInflater.from(getContext()).inflate(resourceId,parent,false);

            // 避免每次调用getView()时都要重新获取控件实例
            viewHolder=new ViewHolder();
            viewHolder.webname=view.findViewById(R.id.webnameLt);
            viewHolder.weburl=view.findViewById(R.id.weburlLt);
            viewHolder.go=view.findViewById(R.id.goLt);
            viewHolder.delete=view.findViewById(R.id.deleteLt);
            // 将ViewHolder存储在View中（即将控件的实例存储在其中）
            view.setTag(viewHolder);
        } else{
            view=convertView;
            viewHolder=(ViewHolder) view.getTag();
        }

        // 获取控件实例，并调用set...方法使其显示出来
        viewHolder.webname.setText(favouritesLt.getName());
        viewHolder.weburl.setText(favouritesLt.getUrl());

        viewHolder.go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FavouritesLt mFavourites=favourites.get(position);
                Toast.makeText(mcontext, "以获取网页" , Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(mcontext, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("url",mFavourites.getUrl());
                intent.putExtras(bundle);
                mcontext.startActivity(intent);
            }
        });

        viewHolder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FavouritesLt mFavourites=favourites.get(position);
                DataSupport.deleteAll(FavouritesLt.class,"url=?",mFavourites.getUrl());
                favourites.remove(position);
                ListAdapterLt.this.notifyDataSetChanged();
            }
        });
        return view;
    }
    class ViewHolder{
        TextView webname;
        TextView weburl;
        Button delete;
        Button go;
    }
}
