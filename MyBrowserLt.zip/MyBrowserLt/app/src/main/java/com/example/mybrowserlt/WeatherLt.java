package com.example.mybrowserlt;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Timer;
import java.util.TimerTask;

public class WeatherLt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weatherlt);
        getWindow().setBackgroundDrawableResource(R.drawable.background);

    }
    String city;//城市
    String high;//最高温度
    String low;//最低温度
    String weather;//天气
    String ptime;//最近更新时间


    public void onClickGetWaetherData(View view) {
        final EditText editText = findViewById(R.id.editcityLt);
        if(editText.getText().toString().equals("")){
            Toast.makeText(WeatherLt.this,"未输入城市，默认查询杭州天气！",Toast.LENGTH_LONG);
            editText.setText("杭州");
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                CountyDataLt countycode = new CountyDataLt();
                String cityName = editText.getText().toString();
                String cityCode = countycode.search(cityName);
                if (cityCode.equals("-1")) {
                    Toast.makeText(WeatherLt.this, "错误的城市名，默认查询杭州天气，请重新输入！", Toast.LENGTH_LONG).show();
                    cityCode ="101210101";
                }
                String weatherUrl = "http://www.weather.com.cn/data/cityinfo/" + cityCode
                        + ".html";

                try {
                    URL url = new URL(weatherUrl);
                    //设置必要的参数信息
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(5000);
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code == 200) {
                        //连接网络成功
                        InputStream in = conn.getInputStream();
                        String data = StreamToolLt.decodeStream(in);


                        //解析json格式的数据
                        JSONObject jsonObj = new JSONObject(data);
                        //获得desc的值

                        JSONObject dataObj = jsonObj.getJSONObject("weatherinfo");
                        city = dataObj.getString("city");
                        high = dataObj.getString("temp2");
                        low = dataObj.getString("temp1");
                        weather = dataObj.getString("weather");
                        ptime = dataObj.getString("ptime");

                    }


                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }).start();

        TextView textView0 = findViewById(R.id.textcityLt);
        textView0.setText("当前城市：" + city);
        TextView textView = findViewById(R.id.texthighLt);
        textView.setText("今日最高气温：" + high);
        TextView textView2 = findViewById(R.id.textlowLt);
        textView2.setText("今日最低气温：" + low);
        TextView textView3 = findViewById(R.id.textweatherLt);
        textView3.setText("当前天气：" + weather);
        TextView textView4 = findViewById(R.id.textupdateLt);
        textView4.setText("最近更新时间：" + ptime);
    }

}
