package com.example.mybrowserlt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.litepal.LitePal;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    WebView webView;        //浏览器界面
    EditText editText;      //输入显示网址
    FloatingActionButton fab;//收藏按钮
    Toolbar toolbar;        //自定义顶部导航栏
    String t;               //获取网页标题
    String url="https://www.baidu.com";//网址
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webviewLt);
        editText=findViewById(R.id.edittextLt);
        toolbar=findViewById(R.id.toolbarLt);
        fab = (FloatingActionButton) findViewById(R.id.fabLt);
        LitePal.getDatabase();
        Bundle bundle = this.getIntent().getExtras();//回传收藏夹选中网站网页
        if(bundle != null)
            url = bundle.getString("url");

        List<String> permissionList=new ArrayList<>();//申请网络权限和存储权限
        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
            permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
            permissionList.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if(!permissionList.isEmpty()) {
            String[] permissions = permissionList.toArray(new String[permissionList.size()]);
            ActivityCompat.requestPermissions(MainActivity.this, permissions, 1);
        }
        setSupportActionBar(toolbar);       //自定义toolbar
        initWebView();                      //初始化webview
        webClient();                        //切换网页自动改变网址栏内容
        enterKeyClient();                   //按下回车自动搜索已输入网址
        favouritesWebsites();               //收藏网页相关
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.goforward:
                onClickGoforward();
                break;
            case R.id.refresh:
                onClickRefresh();
                break;
            case R.id.back:
                onClickBack();
                break;
            case R.id.favorites:
                onClickIntoFavourites();
                break;
            case R.id.weather:
                onClickIntoWeather();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    public void initWebView(){
        webView.getSettings().setJavaScriptEnabled(true);//允许javascript

        WebChromeClient wcc = new WebChromeClient() {//获取标题
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                t=title;
            }
        };
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });

        webView.setWebChromeClient(wcc);
        webView.loadUrl(url);//获取url
        webView.canGoBack();//能够返回
        webView.canGoForward();//能够前进
        editText.setText(webView.getUrl());//设置当前网页
        webView.setDownloadListener(new MyDownLoadListenerLt(this));//定义下载网址监听
    }



    public void onClickRefresh(){
        webView.reload();
    }
    public void onClickBack(){
        webView.goBack();
    }
    public void onClickGoforward(){
        webView.goForward();
    }
    public void onClickIntoFavourites(){
        Intent intent=new Intent(this,FavouritesPageLt.class);
        startActivity(intent);
    }

    public void onClickIntoWeather(){
        Intent intent=new Intent(this,WeatherLt.class);
        startActivity(intent);
    }

    public void onClickSearch(View view){
        String url=editText.getText().toString();
        if(!(url.startsWith("https://") || url.startsWith("http://"))) {
            url="https://"+url;
        }
        if(!(url.endsWith("/"))){
            url=url+"/";
        }
        webView.loadUrl(url);
    }

    public void webClient(){
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url)
            {
                editText.setText(webView.getUrl());
                super.onPageFinished(view, url);
                // 加载完成
            }
        });
    }

    public void enterKeyClient() {
        editText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode==KeyEvent.KEYCODE_ENTER && event.getAction() ==KeyEvent.ACTION_UP) {// 监听到回车键确认
                    String url=editText.getText().toString();
                    if(!(url.startsWith("https://") || url.startsWith("http://"))) {
                        url="https://"+url;
                    }
                    if(!(url.endsWith("/"))){
                        url=url+"/";
                    }
                    webView.loadUrl(url);
                }
                return false;

            }
        });
    }

    public void favouritesWebsites(){

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FavouritesLt favourites=new FavouritesLt();
                favourites.setUrl(webView.getUrl());
                favourites.setName(t);
                Toast.makeText(MainActivity.this,"已收藏网页",Toast.LENGTH_SHORT).show();
                favourites.save();

            }
        });
    }

}

