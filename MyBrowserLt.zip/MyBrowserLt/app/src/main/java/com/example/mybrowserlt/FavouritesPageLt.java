package com.example.mybrowserlt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.litepal.crud.DataSupport;
import org.litepal.util.LogUtil;

import java.util.ArrayList;
import java.util.List;

public class FavouritesPageLt extends AppCompatActivity {
    public int theid;
    private List<FavouritesLt> favouritesLt=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);
        initSchool();
        ListAdapterLt adapter=new ListAdapterLt(FavouritesPageLt.this,R.layout.listview,favouritesLt);
        ListView listView=findViewById(R.id.list_viewLt);
        listView.setAdapter(adapter);
    }

    public void initSchool() {
        List<FavouritesLt> all = DataSupport.findAll(FavouritesLt.class);
        for(FavouritesLt favourites:all){
            String name=favourites.getName();
            String url=favourites.getUrl();
            FavouritesLt a=new FavouritesLt(name,url);
            favouritesLt.add(a);

        }
    }

    public void onClickDelete(View view){
        String stringid=theid+"";
        DataSupport.deleteAll(FavouritesLt.class,"id=?",stringid);
        initSchool();
        ListAdapterLt adapter=new ListAdapterLt(FavouritesPageLt.this,R.layout.listview,favouritesLt);
        ListView listView=findViewById(R.id.list_viewLt);
        listView.setAdapter(adapter);

    }


//    public void onClickEnter(View view){
//        String stringid=theid+"";
//        List<FavouritesLt> all = DataSupport.where("id=?", stringid).find(FavouritesLt.class);
//        for (FavouritesLt favourites : all) {
//            theurl=favourites.getUrl();
//        }
//        Intent intent=new Intent(FavouritesPageLt.this,MainActivity.class);
//        Bundle bundle = new Bundle();
//        bundle.putString("url",theurl);
//        intent.putExtras(bundle);
//        startActivity(intent);
//        finish();
//
//    }
}
