package com.example.mybrowserlt;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;

public class MyDownLoadListenerLt implements DownloadListener {
    private Context context;

    public MyDownLoadListenerLt(Context context) {
        this.context = context;
    }

    @Override
    public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));

        //request.setAllowedOverRoaming(true);
        // 允许下载的网络类型（）
        //request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);
        // 允许该记录在下载管理界面可见
        //request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
        //request.setTitle("新版本Apk");
        //request.setDescription("文件正在下载中......");
        //request.setVisibleInDownloadsUi(true);
        // 获得SD卡的读取权限（安卓6.0以上需要获取相应的权限）
        // getSDPersimmion();
        // 设置下载文件保存路径和路径文件名
        //String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
        //request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,fileName);

        // 获得系统下载管理器
        //final DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        // 添加一个下载任务
        //downloadManager.enqueue(request);

        //安卓9.0以后无法调用系统下载器下载头为http的内容
        //故使用跳转其他第三方app下载
        Uri uri = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        context.startActivity(intent);

    }
}


